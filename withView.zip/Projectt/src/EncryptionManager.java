public class EncryptionManager {
    private Vigen�re_cipher cipher = new Vigen�re_cipher(); // Use your provided class

    // Encrypt the password using your Vigen�re Cipher implementation
    public String encrypt(String plainTextPassword) {
        return cipher.Vigenere_Cipher(plainTextPassword); // Call your encrypt method
    }


    public String decrypt(String encryptedPassword) {
        return cipher.Vigenere_Decipher(encryptedPassword); // Call your decrypt method
    }
}
