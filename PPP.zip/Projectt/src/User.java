public class User {
    private String username;
    private String passwordHash;
    private double balance;  // New balance attribute

    public User(String username, String passwordHash) {
        this.username = username;
        this.passwordHash = passwordHash;
        this.balance = 1000.0;  // Initialize balance to $1000
    }

    // Existing getters
    public String getUsername() {
        return username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    // New getter and setter for balance
    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}